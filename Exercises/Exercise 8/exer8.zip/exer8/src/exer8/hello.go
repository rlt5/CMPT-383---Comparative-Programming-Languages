package exer8

const Message = "Hello world!"